//
//  Subscribes.m
//  RSSRead
//
//  Created by ming on 14-3-24.
//  Copyright (c) 2014年 starming. All rights reserved.
//

#import "Subscribes.h"


@implementation Subscribes

@dynamic total;
@dynamic createDate;
@dynamic favicon;
@dynamic link;
@dynamic summary;
@dynamic title;
@dynamic url;

@end
