//
//  EvLineProgressView.h
//  bingyuhuozhige
//
//  Created by weng xiangxun on 14-4-25.
//  Copyright (c) 2014年 Baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EvLineProgressView : UIView
 - (void)showLine;
- (id)initWithFrame:(CGRect)frame lineColor:(UIColor*)color;
@end
