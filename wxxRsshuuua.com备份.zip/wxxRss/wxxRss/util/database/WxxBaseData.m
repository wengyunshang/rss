//
//  WxxBaseData.m
//  driftbottle
//
//  Created by weng xiangxun on 13-9-29.
//  Copyright (c) 2013年 weng xiangxun. All rights reserved.
//

#import "WxxBaseData.h"

@implementation WxxBaseData


- (id)initWithDictionary:(NSDictionary*)dic{return nil;}
-(void)saveSelfToDB{}
-(void)saveToDB{}
-(void)updateSelf{}
-(void)refreshSelf{}
-(void)deleteSelf{}
+ (id)initWithDictionary:(NSDictionary*)dic{return nil;}

 
@end
