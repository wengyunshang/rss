//
//  LeftHeadView.h
//  zouzhe2.2
//
//  Created by weng xiangxun on 15/3/23.
//  Copyright (c) 2015年 wxx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftHeadView : UIButton
-(void)reflashInfo;
@end
