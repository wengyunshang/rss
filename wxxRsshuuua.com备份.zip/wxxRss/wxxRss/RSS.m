//
//  RSS.m
//  RSSRead
//
//  Created by ming on 14-3-24.
//  Copyright (c) 2014年 starming. All rights reserved.
//

#import "RSS.h"

@implementation RSS

@dynamic author;
@dynamic content;
@dynamic createDate;
@dynamic date;
@dynamic identifier;
@dynamic isFav;
@dynamic link;
@dynamic subscribeUrl;
@dynamic summary;
@dynamic title;
@dynamic updated;
@dynamic isRead;
@end
